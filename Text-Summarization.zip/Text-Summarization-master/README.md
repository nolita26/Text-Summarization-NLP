Headlines of news articles summarized to a summary or short paragraph using NLP.
